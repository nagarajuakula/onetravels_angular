INSERT INTO `goodiesdev`.`users`(`id`,`active`,`billing_address`,`email`,`last_login`,`name`,`password`,`phone`,`registered`,`role`,`status`,`vendor_id`) VALUES(101,true,'ameerpet1','ram1@onpassive.com','2018-03-10 12:16:44','Ram1','$2a$10$0oho5eUbDqKrLH026A2YXuCGnpq07xJpuG/Qu.PYb1VCvi2VMXWNi','9182112651','2018-03-10 12:16:44','ROLE_ADMIN','ACTIVE',NULL);
INSERT INTO `goodiesdev`.`users`(`id`,`active`,`billing_address`,`email`,`last_login`,`name`,`password`,`phone`,`registered`,`role`,`status`,`vendor_id`) VALUES(102,false,'ameerpet2','ram2@onpassive.com','2018-03-10 12:16:44','Ram2','$2a$10$0oho5eUbDqKrLH026A2YXuCGnpq07xJpuG/Qu.PYb1VCvi2VMXWNi','9182112652','2018-03-10 12:16:44','ROLE_VENDOR','ACTIVE',NULL);
INSERT INTO `goodiesdev`.`users`(`id`,`active`,`billing_address`,`email`,`last_login`,`name`,`password`,`phone`,`registered`,`role`,`status`,`vendor_id`) VALUES(103,true,'ameerpet3','ram3@onpassive.com','2018-03-10 12:16:44','Ram3','$2a$10$0oho5eUbDqKrLH026A2YXuCGnpq07xJpuG/Qu.PYb1VCvi2VMXWNi','9182112653','2018-03-10 12:16:44','ROLE_USER','ACTIVE',NULL);

INSERT INTO `goodiesdev`.`shipping_address`(`id`,`address`,`city`,`country`,`is_default`,`state`,`zipcode`,`user_id`) VALUES(1001,'Dummy Address1','Hyderabad1','India1','y','Telangana',500045,101);
INSERT INTO `goodiesdev`.`shipping_address`(`id`,`address`,`city`,`country`,`is_default`,`state`,`zipcode`,`user_id`) VALUES(1002,'Dummy Address2','Hyderabad2','India2','n','Telangana',500045,102);
INSERT INTO `goodiesdev`.`shipping_address`(`id`,`address`,`city`,`country`,`is_default`,`state`,`zipcode`,`user_id`) VALUES(1003,'Dummy Address3','Hyderabad3','India3','y','Telangana',500045,103);

INSERT INTO `goodiesdev`.`product_info`(`id`,`product_code`,`category_type`,`create_time`,`product_description`,`product_icon`,`product_name`,`product_price`,`product_status`,`product_stock`,`update_time`) VALUES (1,'B0001',0,'2018-03-10 12:16:44','Java EE','https://covers.oreillystatic.com/images/9780596516680/lrg.jpg','Head First',10.00,1,200,'2018-03-10 12:16:44');
INSERT INTO `goodiesdev`.`product_info`(`id`,`product_code`,`category_type`,`create_time`,`product_description`,`product_icon`,`product_name`,`product_price`,`product_status`,`product_stock`,`update_time`) VALUES (2,'B0002',1,'2018-03-10 12:16:44','Mans','https://img1.newchic.com/thumb/view/oaupload/newchic/images/00/30/df8a1f83-035c-4942-93d6-49933ac52a34.jpg','Coats',22.00,0,222,'2018-03-10 12:12:46');
INSERT INTO `goodiesdev`.`product_info`(`id`,`product_code`,`category_type`,`create_time`,`product_description`,`product_icon`,`product_name`,`product_price`,`product_status`,`product_stock`,`update_time`) VALUES (3,'B0003',2,'2018-03-10 12:16:44','Everyone likes it', 'https://www.thesun.co.uk/wp-content/uploads/2017/03/nintchdbpict000277254629.jpg?strip=all&w=676', 'Coca Cola', 1.00, 0, 100, '2018-03-10 12:04:13');

INSERT INTO `goodiesdev`.`vendor`(`id`,`description`,`email`,`company_name`,`plan`,`status`)VALUES(121, 'Company1', 'company1@abc.com', 'active', 'This is Company 1', 'Premium');
INSERT INTO `goodiesdev`.`vendor`(`id`,`description`,`email`,`company_name`,`plan`,`status`)VALUES(122, 'Company2', 'company2@abc.com', 'active', 'This is Company 2', 'Premium');
INSERT INTO `goodiesdev`.`vendor`(`id`,`description`,`email`,`company_name`,`plan`,`status`)VALUES(123, 'Company3', 'company3@abc.com', 'active', 'This is Company 3', 'Premium');

INSERT INTO `goodiesdev`.`order_main`(`order_id`,`buyer_address`,`buyer_email`,`buyer_name`,`buyer_phone`,`create_time`,`order_amount`,`order_status`,`update_time`) VALUES (111, '3101 Western Road A', 'customer1@email.com', 'customer1', '9898756787', '2018-03-15 12:52:20.439', 100.00, 0, '2018-03-15 12:52:20.439');
INSERT INTO `goodiesdev`.`order_main`(`order_id`,`buyer_address`,`buyer_email`,`buyer_name`,`buyer_phone`,`create_time`,`order_amount`,`order_status`,`update_time`) VALUES (222, '3102 Western Road B', 'customer2@email.com', 'customer2', '9856789686', '2018-03-15 12:52:29.007', 4.00, 0, '2018-03-15 12:52:29.007');
INSERT INTO `goodiesdev`.`order_main`(`order_id`,`buyer_address`,`buyer_email`,`buyer_name`,`buyer_phone`,`create_time`,`order_amount`,`order_status`,`update_time`) VALUES (333, '3103 Western Road C', 'customer3@email.com', 'customer3', '9746875786', '2018-03-15 12:52:07.428', 180.00, 2, '2018-03-15 12:52:53.664');

INSERT INTO `goodiesdev`.`product_in_order`(`id`,`category_type`,`count`,`product_description`,`product_icon`,`product_id`,`product_name`,`product_price`,`product_stock`,`cart_user_id`,`order_id`) VALUES (1221, 0,1,'Books for learning Java1', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', '10001', 'Core Java1', 30.00,96,NULL, 111);
INSERT INTO `goodiesdev`.`product_in_order`(`id`,`category_type`,`count`,`product_description`,`product_icon`,`product_id`,`product_name`,`product_price`,`product_stock`,`cart_user_id`,`order_id`) VALUES (1222, 0,1,'Books for learning Java2', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', '10002', 'Core Java2', 30.00,96,NULL, 222);
INSERT INTO `goodiesdev`.`product_in_order`(`id`,`category_type`,`count`,`product_description`,`product_icon`,`product_id`,`product_name`,`product_price`,`product_stock`,`cart_user_id`,`order_id`) VALUES (1223, 0,1,'Books for learning Java3', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', '10003', 'Core Java3', 30.00,96,NULL, 333);

INSERT INTO `goodiesdev`.`product_category`(`category_id`,`category_name`,`category_type`,`create_time`,`update_time`) VALUES (1221, 'Books', 0, '2018-03-09 23:03:26', '2018-03-10 00:15:27');
INSERT INTO `goodiesdev`.`product_category`(`category_id`,`category_name`,`category_type`,`create_time`,`update_time`) VALUES (1222, 'Clothes', 2, '2018-03-10 00:15:02', '2018-03-10 00:15:21');
INSERT INTO `goodiesdev`.`product_category`(`category_id`,`category_name`,`category_type`,`create_time`,`update_time`) VALUES (1223, 'Drink', 3, '2018-03-10 01:01:09', '2018-03-10 01:01:09');

INSERT INTO `goodiesdev`.`otp_store`(`otp_id`,`contact_number`,`email_id`,`otp`,`sms_id`) VALUES ('1661','9898335756','customer1@email.com',4567,'7a498e21-a3f3-49ff-850f-32e059f85f43');
INSERT INTO `goodiesdev`.`otp_store`(`otp_id`,`contact_number`,`email_id`,`otp`,`sms_id`) VALUES ('1662','9466754865','customer2@email.com',8945,'6g656h36-a4f4-50gg-657g-67h674j74b67');
INSERT INTO `goodiesdev`.`otp_store`(`otp_id`,`contact_number`,`email_id`,`otp`,`sms_id`) VALUES ('1663','9354563847','customer3@email.com',4345,'8m457b78-b6h6-64th-567k-54n563k47l78');

INSERT INTO `goodiesdev`.`feature_admin`(`feature_id`,`feature_description`,`feature_name`)VALUES(191, 'Electronic1', 'Good usage1');
INSERT INTO `goodiesdev`.`feature_admin`(`feature_id`,`feature_description`,`feature_name`)VALUES(192, 'Electronic2', 'Good usage2');
INSERT INTO `goodiesdev`.`feature_admin`(`feature_id`,`feature_description`,`feature_name`)VALUES(193, 'Electronic3', 'Good usage3');

INSERT INTO `goodiesdev`.`cart`(`user_id`) VALUES (101);
INSERT INTO `goodiesdev`.`cart`(`user_id`) VALUES (102);
INSERT INTO `goodiesdev`.`cart`(`user_id`) VALUES (103);



