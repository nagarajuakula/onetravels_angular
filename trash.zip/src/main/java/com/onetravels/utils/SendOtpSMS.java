package com.onetravels.utils;

import java.util.SplittableRandom;

public class SendOtpSMS {
	public static String generateOTP(int length) {
		SplittableRandom sr = new SplittableRandom();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			sb.append(sr.nextInt(1, 10));
		}
		return sb.toString();
	}
}
