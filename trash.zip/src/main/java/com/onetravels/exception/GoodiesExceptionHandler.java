                                                                                                                                                                                                                                                                                                                                                                                                                        package com.onetravels.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * @author Nagaraju Akula
 *
 */
@ControllerAdvice
public class GoodiesExceptionHandler {
//    private static final logger logger = loggerFactory.getlogger(GlobalExceptionHandler.class);
    
    @ExceptionHandler(value = { AuthenticationException.class })
    public ResponseEntity<Object> handleInvalidInputException(AuthenticationException ex) {
        return new ResponseEntity<Object>(ex.getMessage(),HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(value = { CustomException.class })
    public ResponseEntity<Object> handleException(CustomException ex) {
        return new ResponseEntity<Object>(ex.getMessage(),HttpStatus.NOT_FOUND);
    }
    
    
    @ExceptionHandler(value = { Exception.class })
    public ResponseEntity<Object> handleException(Exception ex) {
        return new ResponseEntity<Object>(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @ExceptionHandler(value = { UserException.class })
    public ResponseEntity<Object> handleException(UserException userException) {
        return new ResponseEntity<Object>(userException.getMessage(),HttpStatus.BAD_REQUEST);
    }
}