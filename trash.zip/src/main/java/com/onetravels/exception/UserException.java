package com.onetravels.exception;

import org.springframework.security.core.AuthenticationException;

public class UserException extends AuthenticationException {

	private static final long serialVersionUID = 1L;

	public UserException(String s) {
		super(s);
	}

}
