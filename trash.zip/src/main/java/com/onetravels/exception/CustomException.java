package com.onetravels.exception;

/**
 * @author Nagaraju Akula
 *
 */
public class CustomException extends Exception {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1937937471428702441L;

	 public CustomException(String s) 
	    { 
	        super(s); 
	    }
}
