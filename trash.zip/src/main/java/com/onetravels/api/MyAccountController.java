package com.onetravels.api;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onetravels.entity.ShippingAddress;
import com.onetravels.entity.User;
import com.onetravels.exception.CustomException;
import com.onetravels.service.MyAccountService;
import com.onetravels.vo.request.PasswordChanger;

/**
 * Created By Farooq Ahamad  on 08/10/2020.
 */
@RestController
@RequestMapping("/account")
public class MyAccountController {
	
	@Autowired
	private MyAccountService myAccountService;
	
	//getting the user account details
	@GetMapping("/getMyAccountDetails/{id}")
	public User getAccountDetails(@PathVariable("id") Long id)
	{
		User user =  myAccountService.getAccountDetails(id);
		return user;
	}
	
	//user able to modify the account details
	@PutMapping("/{accountid}")
	public User editAccountDetails(@PathVariable("accountid") Long id, @RequestBody User userDetails)
	{
		User user = myAccountService.editAccountDetails(id,userDetails);
		return user;
	}
	
	@PostMapping("/save/shipaddress")
	public ShippingAddress saveAddress(@RequestBody ShippingAddress shippingAddress) throws CustomException
	{
		ShippingAddress shippingAddr = myAccountService.saveAddress(shippingAddress);
		return shippingAddr;
	}
	
	/*
	 * @GetMapping("/shipaddress/{accountid}") public List<ShippingAddress>
	 * saveAddress(@PathVariable("accountid") Long id ) { List<ShippingAddress>
	 * shippingAddr = myAccountService.getAddress(id); return shippingAddr; }
	 */
	
	@PutMapping("/shipaddress/{uid}")
	public ShippingAddress updateShippingAddress(@RequestBody ShippingAddress shippingAddress,@PathVariable("uid") Long uid) throws CustomException
	{
		return myAccountService.updateShippingAddress(shippingAddress,uid);
	}
	
	@PostMapping("/password/change/{uid}")
	public String changePassword(@PathVariable("uid") Long uid, @RequestBody PasswordChanger passwordChanger)
	{
		return myAccountService.changePassword(uid,passwordChanger);
	}
	
	@PutMapping("/setdefaultaddr/{uid}/{shipid}")
	public String setDefaultShippingAddress(@RequestBody ShippingAddress shippingAddress,@PathVariable("uid") Long uid) throws CustomException
	{
		return myAccountService.setDefaultShippingAddress(shippingAddress,uid);
	}
}
