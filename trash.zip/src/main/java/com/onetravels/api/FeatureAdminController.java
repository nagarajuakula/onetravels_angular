package com.onetravels.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onetravels.entity.FeatureAdmin;
import com.onetravels.service.FeatureAdminService;

@RestController
@CrossOrigin
public class FeatureAdminController {

	@Autowired
	FeatureAdminService featureAdminService;

	@PostMapping("/admin/feature/new")
	public ResponseEntity<?> createFeature(@Valid @RequestBody FeatureAdmin featureAdmin, BindingResult bindingResult) {
		FeatureAdmin featureNameExist = featureAdminService.getFeature(featureAdmin.getFeatureName());
		if (featureNameExist != null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body("Feature Name already exist");
		}
		if (bindingResult.hasErrors()) {
			return ResponseEntity.badRequest().body(bindingResult);
		}
		FeatureAdmin savedFeatured = featureAdminService.save(featureAdmin);
		return ResponseEntity.ok(savedFeatured);
	}

	@GetMapping("/admin/feature/{featureName}")
	public FeatureAdmin getFeaturePage(@PathVariable("featureName") String featureName) {
		return featureAdminService.getFeature(featureName);

	}

	@PutMapping("/admin/feature/{id}/edit")
	public ResponseEntity<?> edit(@PathVariable("id") Long featureId, @Valid @RequestBody FeatureAdmin featureAdmin,
			BindingResult bindingResult) {
		featureAdmin.setFeatureId(featureId);
		if (bindingResult.hasErrors()) {
			return ResponseEntity.badRequest().body(bindingResult);
		}
		if (!featureId.equals(featureAdmin.getFeatureId())) {
			return ResponseEntity.badRequest().body("Id Not Matched");
		}

		featureAdmin = featureAdminService.update(featureAdmin);
		return ResponseEntity.ok(featureAdmin);
	}

	@DeleteMapping("/admin/feature/{id}/delete")
	public ResponseEntity<?> delete(@PathVariable("id") Long featureId) {
		featureAdminService.delete(featureId);
		return ResponseEntity.ok().build();
	}
}
