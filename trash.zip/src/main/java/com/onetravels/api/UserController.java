package com.onetravels.api;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.Principal;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onetravels.entity.OTPResponse;
import com.onetravels.entity.OTPStore;
import com.onetravels.entity.OtpRequest;
import com.onetravels.entity.ResponseMessage;
import com.onetravels.entity.ShippingAddress;
import com.onetravels.entity.User;
import com.onetravels.entity.Vendor;
import com.onetravels.exception.CustomException;
import com.onetravels.exception.UserException;
import com.onetravels.repository.OTPStoreRepository;
import com.onetravels.repository.ShippingAddressRepository;
import com.onetravels.repository.UserRepository;
import com.onetravels.security.JWT.JwtProvider;
import com.onetravels.service.UserService;
import com.onetravels.service.VendorService;
import com.onetravels.utils.SendOtpSMS;
import com.onetravels.vo.request.LoginForm;
import com.onetravels.vo.response.JwtResponse;

/**
 * Created By SrinivasaRao L on 30/09/2020.
 */
@CrossOrigin
@RestController
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	VendorService vendorService;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtProvider jwtProvider;

	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	OTPStoreRepository otpStoreRepo;
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	ShippingAddressRepository shippingAddressRepo;
	
	@Autowired
	UserRepository userRepository;

	@PostMapping("/login")
	public ResponseEntity<JwtResponse> login(@RequestBody LoginForm loginForm) {

		try {
			String originalPassword = loginForm.getPassword();
			User user1 = userRepository.findByEmail(loginForm.getUsername());
			String encodedPassword = user1.getPassword();
			
			boolean matches = passwordEncoder.matches(originalPassword, encodedPassword);
			
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(loginForm.getUsername(), loginForm.getPassword()));
			SecurityContextHolder.getContext().setAuthentication(authentication);
			String jwt = jwtProvider.generate(authentication);
			UserDetails userDetails = (UserDetails) authentication.getPrincipal();
			User user = userService.findOne(userDetails.getUsername());
			return ResponseEntity.ok(new JwtResponse(jwt, user.getEmail(), user.getName(), user.getRole()));
		} catch (AuthenticationException e) {
			throw new UserException("Incorrect credentials try again");
		}
	}

	@PostMapping("/register")
	public ResponseEntity<?> save(@RequestBody User user) {

		User userExists = userService.findOne(user.getEmail());
		if (userExists != null) {
			return ResponseEntity.status(409).body("Oops!  There is already a user registered with the email provided");
		}
		try {
			return ResponseEntity.ok(userService.save(user));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("please enter valid details");
		}
	}

	@PutMapping("/profile")
	public ResponseEntity<User> update(@RequestBody User user, Principal principal) {

		try {
			if (!principal.getName().equals(user.getEmail()))
				throw new IllegalArgumentException();
			return ResponseEntity.ok(userService.update(user));
		} catch (Exception e) {
			return ResponseEntity.badRequest().build();
		}
	}

	@GetMapping("/profile/{email}")
	public ResponseEntity<User> getProfile(@PathVariable("email") String email, Principal principal) {
		if (principal.getName().equals(email)) {
			return ResponseEntity.ok(userService.findOne(email));
		} else {
			return ResponseEntity.badRequest().build();
		}

	}

	@PostMapping("/forgot")
	public ResponseEntity<?> processForgotPasswordForm(@RequestParam("email") String userEmail) throws Exception {

		User user = userService.findOne(userEmail);
		if (user == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body("We didn't find an account for this e-mail address");
		} else {
			String uuid = UUID.randomUUID().toString();
			StringBuilder builder = new StringBuilder();
			OTPResponse otpResponse = new OTPResponse();
			String otp = null;
			try {
				// TODO: Get API key from properties or environment
				String apiKey = "apiKey=" + "I9rNcAYGALc-YZAyJNR6JHoeREJ8UP0ZLQFJYMg1Wfa";
				otp = SendOtpSMS.generateOTP(4);
				String msg = "&message=" + URLEncoder.encode("Your OTP is  " + otp, "UTF-8");
				String numbers = "&numbers=" + user.getPhone();
				String apiURL = "https://api.textlocal.in/send/?" + apiKey + msg + numbers;
				URL url = new URL(apiURL);
				URLConnection connection = url.openConnection();
				connection.setDoOutput(true);
				BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String line = null;
				while ((line = br.readLine()) != null) {
					builder.append(line).append("\n");
				}

				System.out.println(builder.toString() + "************");

			} catch (Exception e) {
				throw new Exception("Error while sending sms for Reset Password");
			}

			OTPStore otpStore = new OTPStore();
			otpStore.setContactNumber(user.getPhone());
			otpStore.setEmailId(user.getEmail());
			otpStore.setOtp(otp);
			otpStore.setSmsId(uuid);
			otpStoreRepo.save(otpStore);
			otpResponse.setMobileNumber(user.getPhone());
			otpResponse.setUniqueId(uuid);
			// otpResponse.setOtp(Integer.valueOf(otp));
			return ResponseEntity.ok(otpResponse);
		}

	}

	@PostMapping("/valid_otp")
	public ResponseEntity<?> validOTP(@RequestBody OtpRequest otpRequest) {
		Optional<OTPStore> otpResult = userService.validOTP(otpRequest);
		if (otpResult != null)
			return ResponseEntity.ok(otpResult.get().getEmailId());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invaild OTP");

	}
	@PostMapping("/reset")
	public ResponseEntity<?> setNewPassword(@RequestBody User user) {
		User optionalUser = userService.findOne(user.getEmail());
		if (optionalUser != null) {
			optionalUser.setPassword(passwordEncoder.encode(user.getPassword()));

			return ResponseEntity.status(HttpStatus.OK).body(userService.saveUser(optionalUser));
		} else {
			return ResponseEntity.ok(new ResponseMessage(new Date(), HttpStatus.OK, "Fail", request.getRequestURI()));
		}
	}

	
	
	 

	@PostMapping("users/add")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<User> addUser(@RequestBody User user) throws Exception {
		User savedUser = createUserByRole(user, "User");

		return ResponseEntity.ok(savedUser);
	}

	@PutMapping("/user/{id}")
	public ResponseEntity<User> modifyUserById(@RequestBody User user) throws Exception {
		User updatedUser;
		User existingUser = userService.findOne(user.getEmail());
		if (existingUser == null) {
			throw new CustomException("User with mail " + user.getEmail() + " not exists");
		} else {
			updatedUser = userService.update(user);
		}

		return ResponseEntity.ok(updatedUser);
	}

	@PostMapping("/admin")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<User> createAdmin(@RequestBody User user) throws Exception {
		user.setRole("ROLE_ADMIN");
		User savedUser = createUserByRole(user, "Admin");

		return ResponseEntity.ok(savedUser);
	}

	@PostMapping("/vendor")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<Vendor> createVendor(@RequestBody Vendor vendor) throws Exception {
		Optional<Vendor> optionalVendor = vendorService.findVendorByEmail(vendor.getEmail());

		if (optionalVendor.isPresent()) {
			throw new CustomException("Vendor with mail id " + vendor.getEmail() + " already exists");
		}

		Vendor savedVendor = vendorService.save(vendor);

		return ResponseEntity.ok(savedVendor);
	}

	@PostMapping("/user/{id}/shipAddress")
	public ShippingAddress addShippingAddress(@PathVariable("id") Long userId,
			@RequestBody ShippingAddress shippingAddress) throws Exception {
		Optional<User> userDetails = userService.findUserById(userId);
		User userDet = userDetails.get();
		List<ShippingAddress> shippingAddresses1 = userDet.getShippingAddress();
		CopyOnWriteArrayList<ShippingAddress> shippingAddresses=new CopyOnWriteArrayList<>(shippingAddresses1);
		for (ShippingAddress shippingAddr : shippingAddresses) {
			if(shippingAddr.getIsdefault().equalsIgnoreCase("Y"))
			{
				shippingAddr.setIsdefault("N");
				shippingAddressRepo.save(shippingAddr);
			}
		}
		if(shippingAddress.getIsdefault().equalsIgnoreCase("Y"))
		{
			shippingAddress.setIsdefault("Y");
			shippingAddress.setUser(userDet);
			shippingAddressRepo.save(shippingAddress);
			
		}
		else
		{
			shippingAddress.setIsdefault("N");
			shippingAddress.setUser(userDet);
			shippingAddressRepo.save(shippingAddress);
		}
		/*
		 * return userService.findUserById(userId).map(user -> {
		 * shippingAddress.setUser(user); return
		 * userService.saveShippingAddress(shippingAddress); }).orElseThrow(() -> new
		 * CustomException("User not found"));
		 */
		return shippingAddress;
	}

	private User createUserByRole(User user, String role) throws CustomException {
		User existingUser = userService.findOne(user.getEmail());
		if (existingUser != null) {
			throw new CustomException(role + " with mail id " + user.getEmail() + " already exists");
		}

		return userService.save(user);
	}

//    **************************************************************

	@PutMapping("/user")
	public ResponseEntity<?> modifyUser(@RequestBody User user, Principal principal) throws Exception {
		User updatedUser = null;
		String prncplName = principal.getName();
		String role = user.getRole();
		User existingUser = userService.findOne(user.getEmail());

		if (existingUser == null) {
			throw new CustomException("User with mail " + user.getEmail() + " not exists");
		} else if (role.equals("ROLE_ADMIN")) {
			updatedUser = userRepository.save(user);
		} else if (role.equals("ROLE_MANAGER")) {
			if (prncplName.equals(user.getEmail())) {
				try {
					updatedUser = userRepository.save(user);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				throw new CustomException("Access is denied for modifying the vendor admin");
			}
		}

		return ResponseEntity.ok(updatedUser);
	}

	@GetMapping("/users/user/{id}")
	public ResponseEntity<?> getUser(@PathVariable("id") Long userId) throws CustomException {

		Optional<User> user = userService.findUserById(userId);

		if (user.isEmpty()) {
			throw new CustomException("User does not exists");
		}

		return ResponseEntity.ok(user.get());
	}

	@GetMapping("/users/{userRole}")
	public ResponseEntity<Collection<User>> getAllUsersByRole(@PathVariable String userRole) {

		Collection<User> users = userService.findByRole(userRole);

		return ResponseEntity.ok(users);
	}
	
	@GetMapping("/users")
	public ResponseEntity<Collection<User>> getAllUsers(){
		Collection<User> users = userService.getAllUsers();
		return ResponseEntity.ok(users);
		
	}

	@PostMapping("/vendorAdmin/{id}/create")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_MANAGER')")
	public ResponseEntity<?> createVendorAdminstrator(@PathVariable("id") Long vendorId, @RequestBody User user) {

		User userExists = userService.findOne(user.getEmail());
		if (userExists != null) {
			return ResponseEntity.status(409).body("Oops!  There is already a vendor administrator registered with the email provided");
		}
		try {
			Optional<Vendor> optionalVendor = vendorService.findVendorById(vendorId);
	    	
	    	if(optionalVendor.isEmpty()) {
	    		throw new CustomException("Provided Vendor is not exists");
	    	}
	    	user.setRole("ROLE_MANAGER");
			user.setVendorId(vendorId);
			return ResponseEntity.ok(userService.saveVendorAdministrator(user));
		} catch (Exception e) {
			return ResponseEntity.badRequest().build();
		}
	}
	
	@DeleteMapping("/user/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<?> deleteUser(@PathVariable("id") Long userId) throws CustomException {
		Optional<User> optional = userService.findUserById(userId);
		if (optional.isEmpty()) {
			throw new CustomException("User not found");
		}
		
		userService.delete(userId);
		return ResponseEntity.ok().build();
	}
}