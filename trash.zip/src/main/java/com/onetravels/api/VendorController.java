package com.onetravels.api;

import java.security.Principal;
import java.util.Collection;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onetravels.entity.Vendor;
import com.onetravels.exception.CustomException;
import com.onetravels.repository.VendorRepository;
import com.onetravels.service.VendorService;

/**
 * Created By Kranthi kumar G on 05/10/2020.
 */
@CrossOrigin
@RestController
public class VendorController {

	@Autowired
	VendorService vendorService;

	@Autowired
	VendorRepository vendorRepository;
	
	@GetMapping("/vendor/showVendors")
    public ResponseEntity<Collection<Vendor>> showVendors() {
		Collection<Vendor> vendors = vendorService.findAllVendors();
		 return ResponseEntity.ok(vendors);
    }	
	
	@PostMapping("/vendor/create")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<Vendor> createVendor(@RequestBody Vendor vendor) throws Exception {
		Optional<Vendor> optionalVendor = vendorService.findVendorByEmail(vendor.getEmail());

		if (optionalVendor.isPresent()) {
			throw new CustomException("Vendor with mail id " + vendor.getEmail() + " already exists");
		}

		Vendor savedVendor = vendorService.save(vendor);
		return ResponseEntity.ok(savedVendor);
	}

	@GetMapping("/vendor/{id}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<?> getVendorDetails(@PathVariable("id") Long vendorId)
			throws CustomException {
		Optional<Vendor> optionalVendor = vendorService.findVendorById(vendorId);

		if (optionalVendor.isEmpty()) {
			throw new CustomException("Vendor does not exists");
		}
		
//		if (bindingResult.hasErrors()) {
//			return ResponseEntity.badRequest().body(bindingResult);
//		}

		return ResponseEntity.ok(optionalVendor.get());
	}

	@PutMapping("/vendor/{id}/edit")
	@PreAuthorize("{hasRole('ROLE_ADMIN') or hasRole('ROLE_MANAGER')}")
	public ResponseEntity<?> modifyVendor(@PathVariable("id") Long vendorId, @Valid @RequestBody Vendor vendor,
			BindingResult bindingResult, Principal principal) throws CustomException {
		Optional<Vendor> optionalVendor = vendorService.findVendorById(vendorId);
		System.out.println(principal);
		if (optionalVendor.isEmpty()) {
			throw new CustomException("Vendor does not exists");
		}
		if (bindingResult.hasErrors()) {
			return ResponseEntity.badRequest().body(bindingResult);
		}
		if (!vendorId.equals(vendor.getId())) {
			return ResponseEntity.badRequest().body("Id Not Matched");
		}

		return ResponseEntity.ok(vendorService.update(vendor));
	}
	@DeleteMapping("/vendor/{id}")
	public ResponseEntity<?> delete(@PathVariable("id") Long id) throws Exception {
		Optional<Vendor> vendorById = vendorService.findVendorById(id);
		if(vendorById==null) 
			throw new CustomException("VENDOR DOES NOT EXISTS");
			
		vendorService.deleteVendorById(id);
		return ResponseEntity.ok().build();
	}
}
