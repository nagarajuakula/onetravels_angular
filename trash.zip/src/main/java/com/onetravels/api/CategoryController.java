package com.onetravels.api;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onetravels.entity.ProductCategory;
import com.onetravels.entity.ProductInfo;
import com.onetravels.service.CategoryService;
import com.onetravels.service.ProductService;
import com.onetravels.vo.response.CategoryPage;

/**
 * Created By SrinivasaRao L on 30/09/2020.
 */
@RestController
@CrossOrigin
public class CategoryController {
	@Autowired
	CategoryService categoryService;
	@Autowired
	ProductService productService;

	/**
	 * Show products in category
	 *
	 * @param categoryType
	 * @param page
	 * @param size
	 * @return
	 */

	// Get Category Page with the help of category type
	@GetMapping("admin/category/{type}")
	public CategoryPage showOne(@PathVariable("type") Integer categoryType,
			@RequestParam(value = "page", defaultValue = "1") Integer page,
			@RequestParam(value = "size", defaultValue = "3") Integer size) {

		ProductCategory cat = categoryService.findByCategoryType(categoryType);
		PageRequest request = PageRequest.of(page - 1, size);
		Page<ProductInfo> productInCategory = productService.findAllInCategory(categoryType, request);
		CategoryPage tmp = new CategoryPage("", productInCategory);
		tmp.setCategory(cat.getCategoryName());
		return tmp;
	}	

	@PostMapping("/admin/category/new")
	public ResponseEntity<Object> create(@Valid @RequestBody ProductCategory productCategory,
			BindingResult bindingResult) {
		ProductCategory productCategoryNameExists = categoryService
				.findByCategoryName(productCategory.getCategoryName());

		if (productCategoryNameExists != null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body("Category Name already exist");
		}
		if (bindingResult.hasErrors()) {
			return ResponseEntity.badRequest().body(bindingResult);
		}
		ProductCategory savedCategory = categoryService.save(productCategory);
		return ResponseEntity.ok(savedCategory);
	}

	@PutMapping("/admin/category/{id}/edit")
	public ResponseEntity<?> edit(@PathVariable("id") Integer categoryId,
			@Valid @RequestBody ProductCategory productCategory, BindingResult bindingResult) {
		productCategory.setCategoryId(categoryId);
		if (bindingResult.hasErrors()) {
			return ResponseEntity.badRequest().body(bindingResult);
		}
		if (!categoryId.equals(productCategory.getCategoryId())) {
			return ResponseEntity.badRequest().body("Id Not Matched");
		}

		ProductCategory updatedCategory = categoryService.update(productCategory);
		return ResponseEntity.ok(updatedCategory);
	}

	@DeleteMapping("/admin/category/{id}/delete")
	public ResponseEntity<?> delete(@PathVariable("id") Integer categoryId) {
		categoryService.delete(categoryId);
		return ResponseEntity.ok().build();
	}
	@GetMapping("/admin/categories")
	public ResponseEntity<?> getCategories() {
		return ResponseEntity.ok().body(categoryService.findAll());
	}
	
}
