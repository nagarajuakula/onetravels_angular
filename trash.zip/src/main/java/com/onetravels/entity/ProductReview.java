package com.onetravels.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sun.istack.NotNull;

import lombok.Data;
/**
 * 
 * @author swathi
 *
 */
@Entity
@Data
@Table(name="product_review")
@DynamicUpdate
public class ProductReview implements Serializable {
	/**
	 * 
	 */
  private static final long serialVersionUID = -961082090807311506L;
   
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   private Integer reviewId;
   
   @NotNull
   private String productId;
   
   @CreationTimestamp
   @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
   private Date createTime;
   
   @NotNull
   @ColumnDefault("0")
   private Integer categoryType;
   
   @NotNull
   private String productComments;
   
   @NotNull
   private String productReview;
    
   @UpdateTimestamp
   @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
   private Date updateTime;
   
   
   
   public ProductReview() {
	   
   }
}
