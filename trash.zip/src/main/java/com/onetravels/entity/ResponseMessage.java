package com.onetravels.entity;

import java.util.Date;
import java.util.List;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseMessage {

	private Date timeStamp;
	private HttpStatus status;
	private String message;
	private String path;
	private List<String> details;
	public ResponseMessage(Date timeStamp, HttpStatus status, String message, String path) {
		super();
		this.timeStamp = timeStamp;
		this.status = status;
		this.message = message;
		this.path = path;
	}


	}
