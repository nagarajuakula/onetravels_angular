package com.onetravels.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created By Nagaraju Akula on 05/10/2020.
 */
@Entity
@Data
@Table(name = "vendor")
@NoArgsConstructor
public class Vendor implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -4078440102181518163L;

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@NotEmpty
	@Column(name = "company_name")
	private String name;
	
	@NotEmpty
    @Column(unique = true)
	private String email;
	
	@NotEmpty
	private String status = "active";
	
	private String description;
	
	private String plan;
	
	/*
	 * TODO: Add ShippingMethods field
	 */
}
