package com.onetravels.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class OtpRequest extends OTPResponse{

	private String emailId;

	
}
