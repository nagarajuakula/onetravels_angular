package com.onetravels.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import lombok.Data;


@Data
@Entity
public class FeatureAdmin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long featureId;	
	@NotNull
	private String featureName;
	private String featureDescription;	

}
