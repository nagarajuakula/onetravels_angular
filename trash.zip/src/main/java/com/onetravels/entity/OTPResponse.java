package com.onetravels.entity;

import lombok.Data;

@Data
public class OTPResponse {

	private String mobileNumber;
	private String uniqueId;
	private Integer otp;
}
