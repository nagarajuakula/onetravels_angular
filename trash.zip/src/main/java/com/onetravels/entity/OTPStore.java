package com.onetravels.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.Data;

@Entity
@Table(name = "otp_store")
@Data
public class OTPStore {

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name = "otp_id", columnDefinition = "varchar(256)", nullable = false, unique = true)
	private String id;

	@Column(name = "email_id", columnDefinition = "varchar(128)", nullable = false, unique = false)
	private String emailId;

	@Column(name = "otp", columnDefinition = "integer(4) default 0", nullable = false, unique = false)
	private String otp;

	@Column(name = "contact_number", columnDefinition = "varchar(32)", nullable = false, unique = false)
	private String contactNumber;

	@Column(name = "sms_id", columnDefinition = "varchar(64)", nullable = false, unique = true)
	private String smsId;

}
