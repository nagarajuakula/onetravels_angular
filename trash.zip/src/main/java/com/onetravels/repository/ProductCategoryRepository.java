package com.onetravels.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.ProductCategory;

import java.util.List;

/**
 * Created By SrinivasaRao L on 30/09/2020.
 */
public interface ProductCategoryRepository extends JpaRepository<ProductCategory, Integer> {
    // Some category
    List<ProductCategory> findByCategoryTypeInOrderByCategoryTypeAsc(List<Integer> categoryTypes);
    // All category
    List<ProductCategory> findAllByOrderByCategoryType();
    // One category
    ProductCategory findByCategoryType(Integer categoryType);
    
    ProductCategory findByCategoryId(Integer id);
    
    ProductCategory findByCategoryName(String categoryName);
}
