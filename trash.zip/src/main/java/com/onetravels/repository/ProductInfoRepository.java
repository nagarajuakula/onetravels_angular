package com.onetravels.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.onetravels.entity.ProductInfo;

/**
 * Created By SrinivasaRao L on 30/09/2020.
 */
public interface ProductInfoRepository extends JpaRepository<ProductInfo, String> {
    ProductInfo findByProductId(String id);
    // onsale product
    Page<ProductInfo> findAllByProductStatusOrderByProductIdAsc(Integer productStatus, Pageable pageable);

    // product in one category
    Page<ProductInfo> findAllByCategoryTypeOrderByProductIdAsc(Integer categoryType, Pageable pageable);

    Page<ProductInfo> findAllByOrderByProductId(Pageable pageable);
    
    ProductInfo findByProductName(String productName);
    
    List<ProductInfo> findAllByCategoryType(Integer categoryType);
    
  //Store Front getting all fetured products 
    @Query(value="select * from product_info where product_status= 2",nativeQuery=true)
    Page<ProductInfo> findAllByProductStatus(Pageable pageable);
    
    @Query("SELECT m FROM ProductInfo m WHERE m.productName LIKE %:productName%")
	List<ProductInfo> findproductbyProductName(@Param("productName") String productName);

}
