package com.onetravels.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.ProductInOrder;


/**
 * Created By SrinivasaRao L on 30/09/2020.
 */
public interface ProductInOrderRepository extends JpaRepository<ProductInOrder, Long> {

}
