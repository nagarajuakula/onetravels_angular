package com.onetravels.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.User;

public interface MyAccountRepository extends JpaRepository<User, Long>{


}
