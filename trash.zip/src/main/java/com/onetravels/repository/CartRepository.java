package com.onetravels.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.Cart;


/**
 * Created By SrinivasaRao L on 30/09/2020.
 */

public interface CartRepository extends JpaRepository<Cart, Integer> {
}
