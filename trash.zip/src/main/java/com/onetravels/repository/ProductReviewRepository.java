package com.onetravels.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.ProductReview;

public interface ProductReviewRepository extends JpaRepository<ProductReview, String> {
	
	List<ProductReview> findAllByProductId(String productid);

}
