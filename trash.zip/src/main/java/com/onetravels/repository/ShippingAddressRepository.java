/**
 * 
 */
package com.onetravels.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.ShippingAddress;

/**
 * @author Nagaraju Akula
 *
 */
public interface ShippingAddressRepository extends JpaRepository<ShippingAddress, Long> {
	
	List<ShippingAddress> findAllByUserId(Long id);

}
