package com.onetravels.repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.User;

/**
 * Created By SrinivasaRao L on 30/09/2020.
 */

public interface UserRepository extends JpaRepository<User, Long> {
	User findByEmail(String email);

	Collection<User> findAllByRole(String role);

}
