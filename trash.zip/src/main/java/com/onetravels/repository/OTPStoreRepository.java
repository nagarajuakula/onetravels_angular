package com.onetravels.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.OTPStore;

public interface OTPStoreRepository extends JpaRepository<OTPStore, String>{
	
	public Optional<OTPStore> findBySmsId(String otpUniqueId);

}
