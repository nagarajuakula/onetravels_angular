/**
 * 
 */
package com.onetravels.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onetravels.entity.Vendor;

/**
 * @author Nagaraju Akula
 *
 */
public interface VendorRepository extends JpaRepository<Vendor, Long> {

	Optional<Vendor> findByEmail(String email);
	 void deleteById(Long id);
	

}
