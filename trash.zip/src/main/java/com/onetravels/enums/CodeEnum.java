package com.onetravels.enums;

/**
 * Created By SrinivasaRao L on 30/09/2020.
 */
public interface CodeEnum {
    Integer getCode();

}
