package com.onetravels.service;



import java.util.List;

import com.onetravels.entity.ShippingAddress;
import com.onetravels.entity.User;
import com.onetravels.exception.CustomException;
import com.onetravels.vo.request.PasswordChanger;

/**
 * Created By Farooq Ahamad  on 08/10/2020.
 */
public interface MyAccountService {
	
	User getAccountDetails(Long id);
	
	User editAccountDetails(Long id, User userDetails);
	
	ShippingAddress saveAddress(ShippingAddress shippingAddress) throws CustomException;
	
	//List<ShippingAddress> getAddress(Long id);
	
	String changePassword(Long uid,PasswordChanger passwordChanger);
	
	String setDefaultShippingAddress(ShippingAddress shippingAddress,Long uid) throws CustomException;
	
	ShippingAddress updateShippingAddress(ShippingAddress shippingAddress,Long uid) throws CustomException;

}
