package com.onetravels.service;

import java.util.List;

import com.onetravels.entity.ProductCategory;
/**
 * Created By SrinivasaRao L on 29/09/2020.
 */
public interface CategoryService {

    List<ProductCategory> findAll();

    ProductCategory findByCategoryType(Integer categoryType);

    List<ProductCategory> findByCategoryTypeIn(List<Integer> categoryTypeList);

    ProductCategory save(ProductCategory productCategory);
    
    ProductCategory update(ProductCategory productCategory);

    ProductCategory findOne(Integer categoryId);
    
//    void delete(String categoryId);
    
    ProductCategory findByCategoryName(String categoryName);

	void delete(Integer categoryId);
    

}
