package com.onetravels.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.onetravels.entity.ShippingAddress;
import com.onetravels.entity.User;
import com.onetravels.exception.CustomException;
import com.onetravels.repository.MyAccountRepository;
import com.onetravels.repository.ShippingAddressRepository;
import com.onetravels.service.MyAccountService;
import com.onetravels.vo.request.PasswordChanger;

/**
 * Created By Farooq Ahamad  on 08/10/2020.
 */
@Service
public class MyAccountServiceImpl implements MyAccountService {

	@Autowired
	MyAccountRepository myAccountRepository;
	
	@Autowired
	ShippingAddressRepository shippingAddressRepo;
	
	@Autowired
	PasswordEncoder passwordEncoder;

	
	//this method fetches the user account details
	@Override
	public User getAccountDetails(Long id) {
		User userPerson =null;
		
			 Optional<User> user = myAccountRepository.findById(id);
			//String email = user.getEmail();
					if(user.isPresent())
					{
						userPerson = user.get();
						//String email = userPerson.getEmail();
						
					}
					
					
		
		
		
		  //else { throw }
		 
		return userPerson;
	}

	
	@Override
	//this method allows the user account details to edit
	public User editAccountDetails(Long id, User userDetails) {
		User userDet = null;
		User modifiedUser=null;
		
		Optional<User> user = myAccountRepository.findById(id);
		if(user.isPresent())
		{
			 userDet = user.get();
			 userDet.setAddress(userDetails.getAddress());
			 userDet.setEmail(userDetails.getEmail());
			 userDet.setName(userDetails.getName());
			 userDet.setPhone(userDetails.getPhone());
			 userDet.setPassword(passwordEncoder.encode(userDetails.getPassword()));
			 modifiedUser = myAccountRepository.saveAndFlush(userDet);
			 
		}
		else
		{
			
		}
		
		return modifiedUser;
	}


	@Override
	public ShippingAddress saveAddress(ShippingAddress shippingAddress) throws CustomException {
		if(shippingAddress.getIsdefault().equalsIgnoreCase("N"))
		{
			shippingAddressRepo.save(shippingAddress);
		}
		else
		{
			throw new CustomException("In creating the shipping address you cannot choose default address as Y but you can update as Y");
		}
		return shippingAddress;
		
	}


	


	//user wants to change his password after successfull login
	@Override
	public String changePassword(Long uid,PasswordChanger passwordChanger) {
		if(passwordChanger!= null && uid != null)
		{
			Optional<User> user = myAccountRepository.findById(uid);
			if(user.isPresent())
			{
				User userDetails = user.get();
				if(userDetails.getPassword().equals(passwordChanger.getCurrentPassword()))
				{
					if((passwordChanger.getNewPassword() != null) && (passwordChanger.getConfirmPassword() != null))
					{
						if(passwordChanger.getNewPassword().equals(passwordChanger.getConfirmPassword()))
						{
							userDetails.setPassword(passwordEncoder.encode(passwordChanger.getConfirmPassword()));
							myAccountRepository.saveAndFlush(userDetails);
							return "password changed succesfully";
						}
					}
				}
			}
		}
		return "please enter password credentials correctly";
	}


	@Override
	//this method allows the user to set the default shipping address.
	public String setDefaultShippingAddress(ShippingAddress shippingAdd,Long uid) throws CustomException {
		if(uid != null)
		{
			
			Optional<User> user = myAccountRepository.findById(uid);
			User userDet = user.get();
			Optional<ShippingAddress> shippingAddress = shippingAddressRepo.findById(shippingAdd.getId());
			ShippingAddress shipAddress = shippingAddress.get();
			List<ShippingAddress> shippingAddresses1 = userDet.getShippingAddress();
			CopyOnWriteArrayList<ShippingAddress> shippingAddresses = new CopyOnWriteArrayList<>(shippingAddresses1);
			for (ShippingAddress shippingAddr : shippingAddresses) {
				if(shippingAddr.getIsdefault().equalsIgnoreCase("Y"))
				{
					shippingAddr.setIsdefault("N");
					shippingAddressRepo.save(shippingAddr);
				}
			}
			
			if(shippingAdd.getIsdefault().equalsIgnoreCase("Y"))
			{
				shipAddress.setIsdefault("Y");
				
			}
			else
			{
				shipAddress.setIsdefault("N");
			}
			shippingAddressRepo.save(shipAddress);
			/*
			 * if(shipAddress.getIsdefault().equals("Y")) { shipAddress.setIsdefault("Y");
			 * 
			 * 
			 * } else { shipAddress.setIsdefault("N"); }
			 */	
		}
		
		else
		{
			throw new CustomException("please enter valid user id and ship id");
		}
		return "Successfully set as Default Shipping Address";
	}


	@Override
	//this method allows user to update the shipping address
	public ShippingAddress updateShippingAddress(ShippingAddress shippingAddress, Long uid) throws CustomException {
		
		ShippingAddress shippingDetails = null;
		if(shippingAddress != null && uid != null)
		{
			Optional<User> user = myAccountRepository.findById(uid);
			if(user.isEmpty()) {
				throw new CustomException("User is not found");
			}
			User userDet = user.get();
			
			if(uid.equals(userDet.getId()))
			{
				Optional<ShippingAddress> shippingAddr = shippingAddressRepo.findById(shippingAddress.getId());
				shippingDetails = shippingAddr.get();
				shippingDetails.setAddress(shippingAddress.getAddress());
				shippingDetails.setCity(shippingAddress.getCity());
				shippingDetails.setCountry(shippingAddress.getCountry());
				shippingDetails.setState(shippingAddress.getState());
				shippingDetails.setZipcode(shippingAddress.getZipcode());
				shippingDetails.setId(shippingAddress.getId());
				shippingDetails.setIsdefault(shippingAddress.getIsdefault());
//				shippingDetails.setUser(userDet);
				return shippingAddressRepo.save(shippingDetails);
				
			}
		}
		return shippingDetails;
		
		
	}

}
