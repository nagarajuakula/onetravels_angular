package com.onetravels.service.impl;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.onetravels.entity.Cart;
import com.onetravels.entity.OTPStore;
import com.onetravels.entity.OtpRequest;
import com.onetravels.entity.ShippingAddress;
import com.onetravels.entity.User;
import com.onetravels.enums.ResultEnum;
import com.onetravels.exception.MyException;
import com.onetravels.repository.CartRepository;
import com.onetravels.repository.OTPStoreRepository;
import com.onetravels.repository.ShippingAddressRepository;
import com.onetravels.repository.UserRepository;
import com.onetravels.service.UserService;

/**
 * Created By SrinivasaRao L on 29/09/2020.
 */
@Service
@DependsOn("passwordEncoder")
public class UserServiceImpl implements UserService {
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	UserRepository userRepository;
	@Autowired
	CartRepository cartRepository;

	@Autowired
	ShippingAddressRepository shippingAddressRepo;

	@Autowired
	OTPStoreRepository oTPStoreRepository;

	@Override
	public User findOne(String email) {
		return userRepository.findByEmail(email);
	}

	@Override
	public Collection<User> findByRole(String role) {
		return userRepository.findAllByRole(role);
	}

	@Override
	@Transactional
	public User save(User user) {
		// register
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		try {
			User savedUser = userRepository.save(user);

			// initial Cart
			Cart savedCart = cartRepository.save(new Cart(savedUser));
			savedUser.setCart(savedCart);

			return userRepository.save(savedUser);

		} catch (Exception e) {
			throw new MyException(ResultEnum.VALID_ERROR);
		}

	}

	@Override
	@Transactional
	public User update(User user) {
		User oldUser = userRepository.findByEmail(user.getEmail());
		oldUser.setPassword(passwordEncoder.encode(user.getPassword()));
		oldUser.setName(user.getName());
		oldUser.setPhone(user.getPhone());
		oldUser.setAddress(user.getAddress());
		return userRepository.save(oldUser);
	}

	@Override
	public Optional<User> findUserById(Long id) {
		return userRepository.findById(id);
	}

	@Override
	public ShippingAddress saveShippingAddress(ShippingAddress shippingAddress) {
		return shippingAddressRepo.save(shippingAddress);
	}

	@Transactional
	public User saveUser(User user) {

		return userRepository.save(user);

	}

	public Optional<OTPStore> validOTP(OtpRequest otpRequest) {

		Optional<OTPStore> otpResult = oTPStoreRepository.findBySmsId(otpRequest.getUniqueId());

		if (otpRequest.getOtp().equals(Integer.valueOf(otpResult.get().getOtp()))) {
			return otpResult;
		}else {
			return null;
		}

	}
	
	public User saveVendorAdministrator(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		return userRepository.save(user);
	}
	
	public Collection<User> getAllUsers(){
		List<User> users = userRepository.findAll();
		return users;
		
	}
	
	public void delete(Long id) {
		userRepository.deleteById(id);
	}

}
