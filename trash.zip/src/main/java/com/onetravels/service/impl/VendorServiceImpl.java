/**
 * 
 */
package com.onetravels.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.onetravels.entity.Vendor;
import com.onetravels.enums.ResultEnum;
import com.onetravels.exception.CustomException;
import com.onetravels.repository.VendorRepository;
import com.onetravels.service.VendorService;

/**
 * @author Nagaraju Akula
 *
 */
@Service
public class VendorServiceImpl implements VendorService {

	@Autowired
    VendorRepository vendorRepo;
	
	@Override
	public Optional<Vendor> findVendorById(Long id) {
		return vendorRepo.findById(id);
	}

	@Override
	public Optional<Vendor> findVendorByEmail(String email) {
		return vendorRepo.findByEmail(email);
	}

	@Override
	public Vendor save(Vendor vendor) {
		return vendorRepo.save(vendor);
	}
	
	@Override
    @Transactional
    public Vendor update(Vendor vendor) {
         return vendorRepo.save(vendor);
    }

	public List<Vendor> findAllVendors()
	{
		return vendorRepo.findAll();
	}

	@Override
	public void deleteVendorById(Long id) throws CustomException     {
		
		vendorRepo.deleteById(id);
		
	}
	

}
