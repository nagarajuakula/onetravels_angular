package com.onetravels.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.onetravels.entity.ProductCategory;
import com.onetravels.enums.ResultEnum;
import com.onetravels.exception.MyException;
import com.onetravels.repository.ProductCategoryRepository;
import com.onetravels.service.CategoryService;

/**
 * Created By SrinivasaRao L on 29/09/2020.
 */
@Service
public class CategoryServiceImpl implements CategoryService {
	@Autowired
	ProductCategoryRepository productCategoryRepository;

	@Autowired
	CategoryService categoryService;

	@Override
	public List<ProductCategory> findAll() {
		List<ProductCategory> res = productCategoryRepository.findAllByOrderByCategoryType();
		// res.sort(Comparator.comparing(ProductCategory::getCategoryType));
		return res;
	}

	@Override
	public ProductCategory findByCategoryType(Integer categoryType) {
		ProductCategory res = productCategoryRepository.findByCategoryType(categoryType);
		if (res == null)
			throw new MyException(ResultEnum.CATEGORY_NOT_FOUND);
		return res;
	}

	@Override
	public List<ProductCategory> findByCategoryTypeIn(List<Integer> categoryTypeList) {
		List<ProductCategory> res = productCategoryRepository
				.findByCategoryTypeInOrderByCategoryTypeAsc(categoryTypeList);
		// res.sort(Comparator.comparing(ProductCategory::getCategoryType));
		return res;
	}

	@Override
	@Transactional
	public ProductCategory save(ProductCategory productCategory) {
		return productCategoryRepository.save(productCategory);
	}

	@Override
	public ProductCategory findOne(Integer categoryId) {
		ProductCategory productCategory = productCategoryRepository.findByCategoryId(categoryId);
		return productCategory;
	}

//	@Override
//	@Transactional
//	public ProductCategory update(ProductCategory productCategory) {
//		productCategory.setCategoryName();
//		return productCategoryRepository.save(productCategory);
//	}

	@Override
	public void delete(Integer categoryId) {
		ProductCategory productCategory = findOne(categoryId);
		if (productCategory == null)
			throw new MyException(ResultEnum.CATEGORY_NOT_FOUND);
		productCategoryRepository.delete(productCategory);
	}

	@Override
	public ProductCategory findByCategoryName(String categoryName) {
		ProductCategory productCategory = productCategoryRepository.findByCategoryName(categoryName);
		return productCategory;
	}

	@Override
	@Transactional
	public ProductCategory update(ProductCategory productCategory) {

		ProductCategory oldProductCategory = productCategoryRepository.findByCategoryId(productCategory.getCategoryId());
		oldProductCategory.setCategoryName(productCategory.getCategoryName());
		
		return productCategoryRepository.save(oldProductCategory);
	}

}
