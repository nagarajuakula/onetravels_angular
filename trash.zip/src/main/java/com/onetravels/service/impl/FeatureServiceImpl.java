package com.onetravels.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetravels.entity.FeatureAdmin;
import com.onetravels.enums.ResultEnum;
import com.onetravels.exception.MyException;
import com.onetravels.repository.FeatureAdminRepository;
import com.onetravels.service.FeatureAdminService;

@Service
public class FeatureServiceImpl implements FeatureAdminService {

	@Autowired
	FeatureAdminRepository featureAdminRepository;

	@Override
	public FeatureAdmin getFeature(String featureName) {
		return featureAdminRepository.findByFeatureName(featureName);
	}

	@Override
	public FeatureAdmin save(FeatureAdmin featureAdmin) {
		return featureAdminRepository.save(featureAdmin);
	}

	@Override
	public FeatureAdmin update(FeatureAdmin featureAdmin) {

		FeatureAdmin oldfeatureAdmin = featureAdminRepository.getOne(featureAdmin.getFeatureId());
		oldfeatureAdmin.setFeatureName(featureAdmin.getFeatureName());
		oldfeatureAdmin.setFeatureDescription(featureAdmin.getFeatureDescription());
		return featureAdminRepository.save(oldfeatureAdmin);
	}

	@Override
	public void delete(Long featureId) {
		FeatureAdmin featureAdmin = findOne(featureId);
		if (featureAdmin == null)
			throw new MyException(ResultEnum.FEATURE_NOT_FOUND);
		featureAdminRepository.delete(featureAdmin);

	}

	public FeatureAdmin findOne(Long featureId) {
		FeatureAdmin featureAdmin = featureAdminRepository.findByFeatureId(featureId);
		return featureAdmin;
	}

}
