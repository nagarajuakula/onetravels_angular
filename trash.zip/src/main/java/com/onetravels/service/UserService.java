package com.onetravels.service;

import java.util.Collection;
import java.util.Optional;

import com.onetravels.entity.OTPStore;
import com.onetravels.entity.OtpRequest;
import com.onetravels.entity.ShippingAddress;
import com.onetravels.entity.User;

/**
 * Created By SrinivasaRao L on 29/09/2020.
 */
public interface UserService {

	User findOne(String email);

	Optional<User> findUserById(Long id);

	Collection<User> findByRole(String role);
	
	Collection<User> getAllUsers();

	User save(User user);

	User update(User user);

	ShippingAddress saveShippingAddress(ShippingAddress shippingAddress);

	User saveUser(User user);

	Optional<OTPStore> validOTP(OtpRequest otpRequest);
	
	User saveVendorAdministrator(User user);
	
	void delete(Long id);
}
