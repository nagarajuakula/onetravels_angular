package com.onetravels.service;

import java.util.Collection;

import com.onetravels.entity.Cart;
import com.onetravels.entity.ProductInOrder;
import com.onetravels.entity.User;

/**
 * Created By SrinivasaRao L on 29/09/2020.
 */
public interface CartService {
    Cart getCart(User user);

    void mergeLocalCart(Collection<ProductInOrder> productInOrders, User user);

    void delete(String itemId, User user);

    void checkout(User user);
}
