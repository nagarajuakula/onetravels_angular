package com.onetravels.service;

import java.util.List;
import java.util.Optional;

import com.onetravels.entity.Vendor;
import com.onetravels.exception.CustomException;
/**
 * Created By Nagaraju Akula on 05/10/2020.
 */
public interface VendorService {

	Optional<Vendor> findVendorById(Long id);
	
	Optional<Vendor> findVendorByEmail(String email);
	
	Vendor save(Vendor vendor);
	
	Vendor update(Vendor vendor);
	
	List<Vendor> findAllVendors();
	void deleteVendorById(Long id) throws Exception;
}
