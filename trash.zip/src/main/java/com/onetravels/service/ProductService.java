package com.onetravels.service;


import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.onetravels.entity.ProductInfo;
import com.onetravels.entity.ProductReview;

/**
 * Created By SrinivasaRao L on 29/09/2020.
 */
public interface ProductService {

    ProductInfo findOne(String productId);

    // All selling products
    Page<ProductInfo> findUpAll(Pageable pageable);
    // All products
    Page<ProductInfo> findAll(Pageable pageable);
    // All products in a category
    Page<ProductInfo> findAllInCategory(Integer categoryType, Pageable pageable);

    // increase stock
    void increaseStock(String productId, int amount);

    //decrease stock
    void decreaseStock(String productId, int amount);

    ProductInfo offSale(String productId);

    ProductInfo onSale(String productId);

    ProductInfo update(ProductInfo productInfo);
    ProductInfo save(ProductInfo productInfo);

    void delete(String productId);
    
    ProductInfo findByProductName(String productName);
    
    List<ProductInfo> findAllByCategoryType(Integer categoryType);
    
   //Store Front getting all fetured products 
    Page<ProductInfo> findByProductStatus(Pageable pageable);
  
    //Store Front getting all products
    List<ProductInfo>findAllProducts();
    
    List<ProductInfo> searchProducts(String categoryType);

	ProductReview saveProductReview(ProductReview productreview);
	List<ProductReview> findAllByProductReviews(String productid);
}
