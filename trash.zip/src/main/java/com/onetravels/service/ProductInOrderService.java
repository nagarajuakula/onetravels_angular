package com.onetravels.service;

import com.onetravels.entity.ProductInOrder;
import com.onetravels.entity.User;

/**
 * Created By SrinivasaRao L on 29/09/2020.
 */
public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
