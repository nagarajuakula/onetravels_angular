package com.onetravels.service;

import com.onetravels.entity.FeatureAdmin;

public interface FeatureAdminService {
	
	FeatureAdmin getFeature(String featureName);
	
	FeatureAdmin save(FeatureAdmin featureAdmin);
	
	FeatureAdmin update(FeatureAdmin featureAdmin);
	
	void delete(Long featureId);

	FeatureAdmin findOne(Long featureId);

}
