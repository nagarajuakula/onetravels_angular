package com.onetravels.vo.request;

import javax.validation.constraints.NotBlank;

import lombok.Data;

/**
 * Created By SrinivasaRao L on 28/09/2020.
 */
@Data
public class LoginForm {
    @NotBlank
    private String username;
    @NotBlank
    private String password;
}
