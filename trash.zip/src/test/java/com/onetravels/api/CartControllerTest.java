package com.onetravels.api;

import org.junit.Test;

/**
 * Created By SrinivasaRao L on 30/09/2020.
 */
public class CartControllerTest {

    @Test
    public void getCart() {
    }
}
